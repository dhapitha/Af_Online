const User = function (pfirstName,plastName,pBday,pid) {
    this.firstName = pfirstName;
    this.lastName = plastName;
    this.bday = pBday;
    this.id = pid;

}
module.exports = User;