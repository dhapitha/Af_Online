const exp = require('express');
const bodyparser = require('body-parser');

const userobject = require('./User');

const app = exp();
const userArr = [];
app.use(bodyparser.json());

//fetch port
const PORT = process.env.PORT || 3000
app.listen(PORT,() => console.info(`server has started on  ${PORT}`));

//other way
// app.listen(3000, err =>{
//     if(err){
//         console.error(err);
//         return
//     }else
//         console.log("app listening on port 3000");
//
// })

//add user to the array
app.post('/add', function (req,res){
    const user= new userobject(req.body.fname,req.body.lname,new Date(req.body.Bday),Date.now());
    userArr.push(user);
    res.status(200).send({message:"user added to the array ",data:user});
});

// get all users
app.get('/all', function (req,res) {
    try{
       res.status(200).send({data:userArr});
    }catch(e){
        res.status(500).send({message:e});
    }
});

// find by id
app.get('/userbyId/:Id',function (req,res) {
    try{
        const index=userArr.findIndex(x => x.id == req.paramsId)
        if(index > -1){
            res.status(200).send(userArr[index]);
        }else{
            res.status(404).send({message:"invalid id"});
        }
    }catch (e) {
        res.status(500).send({message:e});

    }

})

// update the users
app.put('/update',function (req,res) {
    const index = userArr.findIndex(instance => instance.id == req.paramsId);
    userArr[index].firstName = req.body.fname;
    userArr[index].lastname =req.body. lname;
    userArr[index].bday = req.body.Bday;

    res.status(200).send(userArr[index]);
})
// delete user
app.delete('/delete',function (req,res) {
    try{
        const index = userArr.findIndex(x=> x.id == req.params.id);
        if(index>-1){
            const deluser = userArr.splice(index,1);
            res.status(200).send({message:"user deleted from the array", removedobj:deluser ,data:userArr} );
        }else
            res.status(404).send({message:"invalid id"});
    }catch (e) {
        res.status(500).send({message:e});

    }

})